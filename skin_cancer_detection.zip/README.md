# Skin Cancer Detection using Deep Learning

This project uses a CNN to classify skin lesions as benign or malignant. It includes a training pipeline and a Streamlit GUI.

## Steps:

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Train the model:
```
python training/train_model.py
```

3. Run the GUI:
```
streamlit run gui/app.py
```

## Dataset Structure:
```
data/
├── train/
│   ├── benign/
│   └── malignant/
└── test/
    ├── benign/
    └── malignant/
```