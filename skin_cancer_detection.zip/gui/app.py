import streamlit as st
from prediction.predict import predict_image

st.title("Skin Cancer Detection")
uploaded_file = st.file_uploader("Choose an image of a skin lesion", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    with open("temp.jpg", "wb") as f:
        f.write(uploaded_file.read())
    st.image("temp.jpg", caption="Uploaded Image", use_column_width=True)
    prediction = predict_image("temp.jpg")
    st.write(f"Prediction: **{prediction}**")